export class SpeechToTextProcessor {
  private recognition: SpeechRecognition | null = null;
  private isSupported: boolean;

  constructor() {
    // Check for browser support
    const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;
    this.isSupported = !!SpeechRecognition;
    
    if (this.isSupported) {
      this.recognition = new SpeechRecognition();
      this.setupRecognition();
    }
  }

  private setupRecognition() {
    if (!this.recognition) return;

    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';
  }

  public isRecognitionSupported(): boolean {
    return this.isSupported;
  }

  public async transcribeFromAudio(audioFile: File): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!this.isSupported || !this.recognition) {
        reject(new Error('Speech recognition is not supported in this browser'));
        return;
      }

      let finalTranscript = '';
      let timeoutId: NodeJS.Timeout;

      // Create audio element to play the file for recognition
      const audio = new Audio();
      const audioUrl = URL.createObjectURL(audioFile);
      audio.src = audioUrl;

      this.recognition.onresult = (event) => {
        let interimTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          } else {
            interimTranscript += transcript;
          }
        }

        // Clear existing timeout and set a new one
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          this.recognition?.stop();
        }, 3000); // Stop if no speech detected for 3 seconds
      };

      this.recognition.onend = () => {
        audio.pause();
        URL.revokeObjectURL(audioUrl);
        clearTimeout(timeoutId);
        
        if (finalTranscript.trim()) {
          resolve(finalTranscript.trim());
        } else {
          reject(new Error('No speech detected in the audio file'));
        }
      };

      this.recognition.onerror = (event) => {
        audio.pause();
        URL.revokeObjectURL(audioUrl);
        clearTimeout(timeoutId);
        reject(new Error(`Speech recognition error: ${event.error}`));
      };

      // Start recognition and play audio
      this.recognition.start();
      
      // Play audio through speakers so recognition can pick it up
      audio.play().catch(() => {
        // If autoplay is blocked, we'll try a different approach
        this.processAudioFileDirectly(audioFile)
          .then(resolve)
          .catch(reject);
      });
    });
  }

  private async processAudioFileDirectly(audioFile: File): Promise<string> {
    // Alternative approach: Use Web Audio API to process the audio
    return new Promise((resolve, reject) => {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const fileReader = new FileReader();

      fileReader.onload = async (e) => {
        try {
          const arrayBuffer = e.target?.result as ArrayBuffer;
          const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
          
          // Create a MediaStreamSource from the audio buffer
          const source = audioContext.createBufferSource();
          const destination = audioContext.createMediaStreamDestination();
          
          source.buffer = audioBuffer;
          source.connect(destination);
          
          // Use MediaRecorder to capture the audio stream
          const mediaStream = destination.stream;
          
          if (!this.recognition) {
            reject(new Error('Speech recognition not available'));
            return;
          }

          let finalTranscript = '';
          
          this.recognition.onresult = (event) => {
            for (let i = event.resultIndex; i < event.results.length; i++) {
              if (event.results[i].isFinal) {
                finalTranscript += event.results[i][0].transcript + ' ';
              }
            }
          };

          this.recognition.onend = () => {
            audioContext.close();
            resolve(finalTranscript.trim() || 'No speech detected');
          };

          this.recognition.onerror = (event) => {
            audioContext.close();
            reject(new Error(`Speech recognition error: ${event.error}`));
          };

          // Start recognition
          this.recognition.start();
          source.start();
          
          // Stop after the audio duration
          setTimeout(() => {
            this.recognition?.stop();
          }, (audioBuffer.duration + 1) * 1000);

        } catch (error) {
          audioContext.close();
          reject(new Error('Failed to process audio file'));
        }
      };

      fileReader.onerror = () => {
        reject(new Error('Failed to read audio file'));
      };

      fileReader.readAsArrayBuffer(audioFile);
    });
  }

  public async transcribeFromURL(audioUrl: string): Promise<string> {
    // For demo purposes, return a mock transcription
    // In a real application, you would process the audio URL
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve("This is a demo transcription. In a production environment, this would contain the actual speech-to-text conversion of your audio file.");
      }, 2000);
    });
  }
}