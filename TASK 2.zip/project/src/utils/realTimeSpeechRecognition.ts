export class RealTimeSpeechProcessor {
  private recognition: SpeechRecognition | null = null;
  private isSupported: boolean;
  private onTranscriptionCallback: ((text: string, isFinal: boolean) => void) | null = null;
  private onErrorCallback: ((error: string) => void) | null = null;
  private restartTimeout: NodeJS.Timeout | null = null;

  constructor() {
    const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;
    this.isSupported = !!SpeechRecognition;
    
    if (this.isSupported) {
      this.recognition = new SpeechRecognition();
      this.setupRecognition();
    }
  }

  private setupRecognition() {
    if (!this.recognition) return;

    // Configure recognition settings for optimal real-time performance
    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';
    this.recognition.maxAlternatives = 1;
    
    // Reduce latency
    if ('webkitSpeechRecognition' in window) {
      (this.recognition as any).serviceURI = 'wss://www.google.com/speech-api/full-duplex/v1/up';
    }

    this.recognition.onstart = () => {
      console.log('Speech recognition started');
    };

    this.recognition.onresult = (event) => {
      if (!this.onTranscriptionCallback) return;

      let interimTranscript = '';
      let finalTranscript = '';

      // Process all results from the current session
      for (let i = 0; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        
        if (event.results[i].isFinal) {
          finalTranscript += transcript + ' ';
        } else {
          interimTranscript += transcript;
        }
      }

      // Send updates to callback
      if (finalTranscript) {
        this.onTranscriptionCallback(finalTranscript.trim(), true);
      }
      if (interimTranscript) {
        this.onTranscriptionCallback(interimTranscript, false);
      }
    };

    this.recognition.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
      
      if (this.onErrorCallback) {
        let errorMessage = 'Speech recognition error occurred';
        
        switch (event.error) {
          case 'not-allowed':
            errorMessage = 'Microphone access denied. Please allow microphone access.';
            break;
          case 'no-speech':
            errorMessage = 'No speech detected. Please try speaking louder.';
            break;
          case 'audio-capture':
            errorMessage = 'Audio capture failed. Please check your microphone.';
            break;
          case 'network':
            errorMessage = 'Network error occurred. Please check your connection.';
            break;
          case 'service-not-allowed':
            errorMessage = 'Speech recognition service not allowed.';
            break;
          default:
            errorMessage = `Speech recognition error: ${event.error}`;
        }
        
        this.onErrorCallback(errorMessage);
      }
    };

    this.recognition.onend = () => {
      console.log('Speech recognition ended');
      
      // Auto-restart recognition if it stops unexpectedly
      if (this.isRecording()) {
        this.restartTimeout = setTimeout(() => {
          this.startRecognition();
        }, 100);
      }
    };
  }

  public isRecognitionSupported(): boolean {
    return this.isSupported;
  }

  public startRecognition(): boolean {
    if (!this.recognition || !this.isSupported) {
      return false;
    }

    try {
      this.recognition.start();
      return true;
    } catch (error) {
      console.error('Failed to start recognition:', error);
      return false;
    }
  }

  public stopRecognition(): void {
    if (this.restartTimeout) {
      clearTimeout(this.restartTimeout);
      this.restartTimeout = null;
    }

    if (this.recognition) {
      this.recognition.stop();
    }
  }

  public isRecording(): boolean {
    // This is a simplified check - in a real implementation you'd track state
    return this.recognition !== null;
  }

  public setTranscriptionCallback(callback: (text: string, isFinal: boolean) => void): void {
    this.onTranscriptionCallback = callback;
  }

  public setErrorCallback(callback: (error: string) => void): void {
    this.onErrorCallback = callback;
  }

  public setLanguage(language: string): void {
    if (this.recognition) {
      this.recognition.lang = language;
    }
  }

  public getAvailableLanguages(): string[] {
    // Common language codes supported by most browsers
    return [
      'en-US', 'en-GB', 'en-AU', 'en-CA', 'en-IN',
      'es-ES', 'es-MX', 'fr-FR', 'de-DE', 'it-IT',
      'pt-BR', 'ru-RU', 'ja-JP', 'ko-KR', 'zh-CN',
      'ar-SA', 'hi-IN', 'nl-NL', 'sv-SE', 'da-DK'
    ];
  }
}