import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Mic, MicOff, Square, Play, Pause } from 'lucide-react';

interface RealTimeRecorderProps {
  onTranscriptionUpdate: (text: string, isFinal: boolean) => void;
  isSupported: boolean;
}

export const RealTimeRecorder: React.FC<RealTimeRecorderProps> = ({
  onTranscriptionUpdate,
  isSupported
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number>();

  useEffect(() => {
    if (isSupported) {
      const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      setupRecognition();
    }

    return () => {
      cleanup();
    };
  }, [isSupported]);

  const setupRecognition = () => {
    if (!recognitionRef.current) return;

    const recognition = recognitionRef.current;
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript + ' ';
        } else {
          interimTranscript += transcript;
        }
      }

      if (finalTranscript) {
        onTranscriptionUpdate(finalTranscript.trim(), true);
      } else if (interimTranscript) {
        onTranscriptionUpdate(interimTranscript, false);
      }
    };

    recognition.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
      if (event.error === 'not-allowed') {
        alert('Microphone access denied. Please allow microphone access and try again.');
      }
      stopRecording();
    };

    recognition.onend = () => {
      if (isRecording && !isPaused) {
        // Restart recognition if it stops unexpectedly
        try {
          recognition.start();
        } catch (error) {
          console.error('Failed to restart recognition:', error);
        }
      }
    };
  };

  const setupAudioVisualization = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      analyserRef.current = audioContextRef.current.createAnalyser();
      
      analyserRef.current.fftSize = 256;
      source.connect(analyserRef.current);

      updateAudioLevel();
    } catch (error) {
      console.error('Error accessing microphone:', error);
      throw error;
    }
  };

  const updateAudioLevel = () => {
    if (!analyserRef.current) return;

    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
    analyserRef.current.getByteFrequencyData(dataArray);
    
    const average = dataArray.reduce((sum, value) => sum + value, 0) / dataArray.length;
    setAudioLevel(average / 255);

    if (isRecording) {
      animationFrameRef.current = requestAnimationFrame(updateAudioLevel);
    }
  };

  const startRecording = async () => {
    if (!isSupported || !recognitionRef.current) return;

    try {
      await setupAudioVisualization();
      recognitionRef.current.start();
      setIsRecording(true);
      setIsPaused(false);
      onTranscriptionUpdate('', false);
    } catch (error) {
      console.error('Failed to start recording:', error);
      alert('Failed to access microphone. Please check your permissions.');
    }
  };

  const pauseRecording = () => {
    if (recognitionRef.current && isRecording) {
      recognitionRef.current.stop();
      setIsPaused(true);
    }
  };

  const resumeRecording = () => {
    if (recognitionRef.current && isRecording && isPaused) {
      try {
        recognitionRef.current.start();
        setIsPaused(false);
      } catch (error) {
        console.error('Failed to resume recording:', error);
      }
    }
  };

  const stopRecording = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    cleanup();
    setIsRecording(false);
    setIsPaused(false);
    setAudioLevel(0);
  }, []);

  const cleanup = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
  };

  if (!isSupported) {
    return (
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 text-center">
        <MicOff className="w-8 h-8 text-amber-600 mx-auto mb-3" />
        <h3 className="font-semibold text-amber-800 mb-2">Real-time Speech Recognition Unavailable</h3>
        <p className="text-amber-700 text-sm">
          Your browser doesn't support real-time speech recognition. Please use Chrome, Edge, or Safari for the best experience.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
      <div className="text-center space-y-6">
        <div className="relative">
          <button
            onClick={isRecording ? stopRecording : startRecording}
            disabled={isPaused}
            className={`relative w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 ${
              isRecording
                ? 'bg-red-500 hover:bg-red-600 shadow-lg'
                : 'bg-blue-600 hover:bg-blue-700 shadow-md hover:shadow-lg'
            } ${isPaused ? 'opacity-50' : ''}`}
          >
            {isRecording ? (
              <Square className="w-8 h-8 text-white" />
            ) : (
              <Mic className="w-8 h-8 text-white" />
            )}
            
            {/* Audio level visualization */}
            {isRecording && !isPaused && (
              <div 
                className="absolute inset-0 rounded-full border-4 border-white/30 animate-pulse"
                style={{
                  transform: `scale(${1 + audioLevel * 0.3})`,
                  opacity: 0.7 + audioLevel * 0.3
                }}
              />
            )}
          </button>

          {/* Pause/Resume button */}
          {isRecording && (
            <button
              onClick={isPaused ? resumeRecording : pauseRecording}
              className="absolute -right-2 -bottom-2 w-10 h-10 bg-gray-600 hover:bg-gray-700 text-white rounded-full flex items-center justify-center transition-colors shadow-md"
            >
              {isPaused ? (
                <Play className="w-4 h-4 ml-0.5" />
              ) : (
                <Pause className="w-4 h-4" />
              )}
            </button>
          )}
        </div>

        <div className="space-y-2">
          <h3 className="text-lg font-semibold text-gray-900">
            {isRecording 
              ? isPaused 
                ? 'Recording Paused' 
                : 'Listening...' 
              : 'Click to Start Recording'
            }
          </h3>
          
          {isRecording && (
            <div className="flex items-center justify-center space-x-2">
              <div className="flex space-x-1">
                {[...Array(5)].map((_, i) => (
                  <div
                    key={i}
                    className={`w-1 h-4 bg-blue-500 rounded-full transition-all duration-150 ${
                      audioLevel * 5 > i ? 'opacity-100' : 'opacity-30'
                    }`}
                    style={{
                      height: `${8 + (audioLevel * 5 > i ? audioLevel * 20 : 0)}px`
                    }}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-600">
                {isPaused ? 'Paused' : 'Recording'}
              </span>
            </div>
          )}
          
          <p className="text-sm text-gray-500">
            {isRecording 
              ? 'Speak clearly into your microphone. Click the square to stop.'
              : 'Real-time speech-to-text conversion. Your voice will be transcribed instantly.'
            }
          </p>
        </div>
      </div>
    </div>
  );
};