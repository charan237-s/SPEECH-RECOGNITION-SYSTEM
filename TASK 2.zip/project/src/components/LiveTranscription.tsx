import React, { useState, useEffect, useRef } from 'react';
import { Copy, Download, Trash2, CheckCircle } from 'lucide-react';

interface LiveTranscriptionProps {
  interimText: string;
  finalText: string;
  isRecording: boolean;
}

export const LiveTranscription: React.FC<LiveTranscriptionProps> = ({
  interimText,
  finalText,
  isRecording
}) => {
  const [copied, setCopied] = useState(false);
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  const fullText = finalText + (interimText ? ' ' + interimText : '');

  useEffect(() => {
    const words = fullText.trim().split(/\s+/).filter(word => word.length > 0);
    setWordCount(words.length);
    setCharCount(fullText.length);
  }, [fullText]);

  useEffect(() => {
    // Auto-scroll to bottom when new text is added
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [fullText]);

  const handleCopy = async () => {
    if (!finalText.trim()) return;
    
    try {
      await navigator.clipboard.writeText(finalText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  const handleDownload = () => {
    if (!finalText.trim()) return;

    const element = document.createElement('a');
    const file = new Blob([finalText], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `transcription-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleClear = () => {
    // This would need to be handled by parent component
    if (window.confirm('Are you sure you want to clear the transcription?')) {
      window.location.reload();
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 bg-gray-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h3 className="text-lg font-semibold text-gray-900">Live Transcription</h3>
            {isRecording && (
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-red-600 font-medium">LIVE</span>
              </div>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopy}
              disabled={!finalText.trim()}
              className="flex items-center space-x-1 px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
            >
              {copied ? (
                <>
                  <CheckCircle className="w-3 h-3 text-emerald-600" />
                  <span className="text-emerald-600">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy</span>
                </>
              )}
            </button>
            
            <button
              onClick={handleDownload}
              disabled={!finalText.trim()}
              className="flex items-center space-x-1 px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
            >
              <Download className="w-3 h-3" />
              <span>Save</span>
            </button>
            
            <button
              onClick={handleClear}
              disabled={!fullText.trim()}
              className="flex items-center space-x-1 px-3 py-1.5 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear</span>
            </button>
          </div>
        </div>
        
        {/* Stats */}
        <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
          <span>{wordCount} words</span>
          <span>{charCount} characters</span>
          {isRecording && <span className="text-blue-600">● Recording in progress</span>}
        </div>
      </div>

      {/* Transcription Content */}
      <div 
        ref={scrollRef}
        className="p-6 max-h-96 overflow-y-auto"
      >
        {!fullText.trim() ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Copy className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-500">
              {isRecording 
                ? 'Start speaking to see your words appear here in real-time...' 
                : 'Click the microphone button to start recording and see live transcription'
              }
            </p>
          </div>
        ) : (
          <div className="prose max-w-none">
            <p className="text-gray-800 leading-relaxed whitespace-pre-wrap text-base">
              <span className="text-gray-900">{finalText}</span>
              {interimText && (
                <span className="text-blue-600 bg-blue-50 px-1 rounded animate-pulse">
                  {interimText}
                </span>
              )}
              {isRecording && (
                <span className="inline-block w-2 h-5 bg-blue-600 ml-1 animate-pulse"></span>
              )}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};