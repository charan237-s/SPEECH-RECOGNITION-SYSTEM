import React, { useState, useCallback, useEffect } from 'react';
import { Mic, AlertCircle, Settings, Globe } from 'lucide-react';
import { RealTimeRecorder } from './components/RealTimeRecorder';
import { LiveTranscription } from './components/LiveTranscription';
import { FileUpload } from './components/FileUpload';
import { AudioPlayer } from './components/AudioPlayer';
import { TranscriptionDisplay } from './components/TranscriptionDisplay';
import { SpeechToTextProcessor } from './utils/speechRecognition';
import { RealTimeSpeechProcessor } from './utils/realTimeSpeechRecognition';

interface TranscriptionState {
  text: string;
  isLoading: boolean;
  error: string | null;
  audioUrl: string | null;
  fileName: string | null;
}

interface LiveTranscriptionState {
  finalText: string;
  interimText: string;
  isRecording: boolean;
}

function App() {
  const [mode, setMode] = useState<'live' | 'upload'>('live');
  const [language, setLanguage] = useState('en-US');
  const [showSettings, setShowSettings] = useState(false);
  
  // File upload state
  const [transcriptionState, setTranscriptionState] = useState<TranscriptionState>({
    text: '',
    isLoading: false,
    error: null,
    audioUrl: null,
    fileName: null
  });

  // Live transcription state
  const [liveState, setLiveState] = useState<LiveTranscriptionState>({
    finalText: '',
    interimText: '',
    isRecording: false
  });

  const fileProcessor = new SpeechToTextProcessor();
  const liveProcessor = new RealTimeSpeechProcessor();

  useEffect(() => {
    liveProcessor.setLanguage(language);
  }, [language, liveProcessor]);

  const handleLiveTranscriptionUpdate = useCallback((text: string, isFinal: boolean) => {
    setLiveState(prev => {
      if (isFinal) {
        return {
          ...prev,
          finalText: prev.finalText + text + ' ',
          interimText: ''
        };
      } else {
        return {
          ...prev,
          interimText: text
        };
      }
    });
  }, []);

  const handleFileSelect = useCallback(async (file: File) => {
    setTranscriptionState(prev => ({
      ...prev,
      isLoading: true,
      error: null,
      audioUrl: URL.createObjectURL(file),
      fileName: file.name
    }));

    try {
      let transcription: string;

      if (fileProcessor.isRecognitionSupported()) {
        try {
          transcription = await fileProcessor.transcribeFromAudio(file);
        } catch (speechError) {
          console.warn('Speech recognition failed, using demo transcription:', speechError);
          transcription = await fileProcessor.transcribeFromURL('demo');
        }
      } else {
        transcription = "Speech recognition is not supported in this browser. In a production environment, this would integrate with cloud-based speech-to-text services like Google Speech-to-Text, Azure Speech Services, or AWS Transcribe for broader browser compatibility and better accuracy.";
      }

      setTranscriptionState(prev => ({
        ...prev,
        text: transcription,
        isLoading: false
      }));

    } catch (error) {
      setTranscriptionState(prev => ({
        ...prev,
        error: error instanceof Error ? error.message : 'An error occurred during transcription',
        isLoading: false
      }));
    }
  }, [fileProcessor]);

  const resetFileUpload = useCallback(() => {
    if (transcriptionState.audioUrl) {
      URL.revokeObjectURL(transcriptionState.audioUrl);
    }
    setTranscriptionState({
      text: '',
      isLoading: false,
      error: null,
      audioUrl: null,
      fileName: null
    });
  }, [transcriptionState.audioUrl]);

  const clearLiveTranscription = useCallback(() => {
    setLiveState({
      finalText: '',
      interimText: '',
      isRecording: false
    });
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-emerald-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="p-3 bg-blue-600 rounded-2xl">
              <Mic className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Real-Time Speech Recognition
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Experience instant speech-to-text conversion with live microphone input or upload audio files for transcription.
          </p>
        </div>

        {/* Mode Toggle */}
        <div className="max-w-md mx-auto mb-8">
          <div className="bg-white rounded-xl p-2 shadow-sm border border-gray-200">
            <div className="grid grid-cols-2 gap-1">
              <button
                onClick={() => setMode('live')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  mode === 'live'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Live Recording
              </button>
              <button
                onClick={() => setMode('upload')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  mode === 'upload'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                File Upload
              </button>
            </div>
          </div>
        </div>

        {/* Settings Panel */}
        <div className="max-w-2xl mx-auto mb-8">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="flex items-center space-x-2 mx-auto px-4 py-2 bg-white rounded-lg shadow-sm border border-gray-200 hover:bg-gray-50 transition-colors"
          >
            <Settings className="w-4 h-4" />
            <span className="text-sm font-medium">Settings</span>
          </button>
          
          {showSettings && (
            <div className="mt-4 bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="space-y-4">
                <div>
                  <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-2">
                    <Globe className="w-4 h-4" />
                    <span>Language</span>
                  </label>
                  <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="en-US">English (US)</option>
                    <option value="en-GB">English (UK)</option>
                    <option value="es-ES">Spanish (Spain)</option>
                    <option value="es-MX">Spanish (Mexico)</option>
                    <option value="fr-FR">French</option>
                    <option value="de-DE">German</option>
                    <option value="it-IT">Italian</option>
                    <option value="pt-BR">Portuguese (Brazil)</option>
                    <option value="ja-JP">Japanese</option>
                    <option value="ko-KR">Korean</option>
                    <option value="zh-CN">Chinese (Simplified)</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Browser Support Notice */}
        {!liveProcessor.isRecognitionSupported() && (
          <div className="max-w-2xl mx-auto mb-8">
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-medium text-amber-800">Limited Browser Support</h3>
                <p className="text-sm text-amber-700 mt-1">
                  Your browser has limited speech recognition support. For the best real-time experience, 
                  use Chrome, Edge, or Safari.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="max-w-4xl mx-auto space-y-8">
          {mode === 'live' ? (
            <>
              {/* Real-time Recorder */}
              <RealTimeRecorder
                onTranscriptionUpdate={handleLiveTranscriptionUpdate}
                isSupported={liveProcessor.isRecognitionSupported()}
              />

              {/* Live Transcription Display */}
              <LiveTranscription
                interimText={liveState.interimText}
                finalText={liveState.finalText}
                isRecording={liveState.isRecording}
              />
            </>
          ) : (
            <>
              {/* Error Display */}
              {transcriptionState.error && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start space-x-3">
                  <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <h3 className="font-medium text-red-800">Transcription Error</h3>
                    <p className="text-sm text-red-700 mt-1">{transcriptionState.error}</p>
                  </div>
                  <button
                    onClick={resetFileUpload}
                    className="text-red-600 hover:text-red-800 text-sm font-medium"
                  >
                    Try Again
                  </button>
                </div>
              )}

              {/* File Upload */}
              <FileUpload 
                onFileSelect={handleFileSelect}
                isProcessing={transcriptionState.isLoading}
              />

              {/* Audio Player */}
              {transcriptionState.audioUrl && transcriptionState.fileName && (
                <AudioPlayer 
                  audioUrl={transcriptionState.audioUrl}
                  fileName={transcriptionState.fileName}
                />
              )}

              {/* Transcription Display */}
              <TranscriptionDisplay
                transcription={transcriptionState.text}
                isLoading={transcriptionState.isLoading}
                fileName={transcriptionState.fileName || undefined}
              />
            </>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-16 pt-8 border-t border-gray-200">
          <p className="text-gray-500 text-sm">
            Powered by Web Speech API • Real-time speech recognition technology
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;